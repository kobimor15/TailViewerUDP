#include "Client.h"

namespace udp
{
	void Client::init(CommunicationInfo* commuInfo)
	{
		WSADATA wsaData;
		if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0)
		{
			std::cout << "Error - WSAStartup failed. Error:" << WSAGetLastError() << "\n";
			getchar();
			exit(1);
		}

		/* Create the socket: */
		m_local_socket = socket(AF_INET, SOCK_DGRAM, 0);
		if (m_local_socket == INVALID_SOCKET)
		{
			std::cout << "Error - WSAStartup failed. Error:" << WSAGetLastError() << "\n";
			getchar();
			exit(1);
		}

		memset(&m_remote_address, 0, sizeof(m_remote_address));

		m_remote_address.sin_family = AF_INET;
		m_remote_address.sin_port = htons(commuInfo->remotePort);
		//m_remote_address.sin_addr.s_addr = INADDR_ANY; //WHAT IS THE DIFFERENCE???
		int error_code = inet_pton(AF_INET, commuInfo->remoteIP, &(m_remote_address.sin_addr));
		if (error_code <= 0)
		{
			std::cout << "Error - failed to convert ip address to struct in_addr. Error:" << WSAGetLastError() << "\n";
			getchar();
			exit(1);
		}

		//....
		//....
	}

	std::string Client::createMessage(std::string msg)
	{
		msg.append(m_commuInfo->localIP);
		msg.append(std::to_string(m_commuInfo->localPort));
		return msg;
	}

	void Client::sendMessageToServer(std::string msg)
	{
		const char* c_msg = msg.c_str();
		int error_code = sendto(m_local_socket, c_msg, sizeof(c_msg), 0, (struct sockaddr*)(&m_remote_address), sizeof(m_remote_address));
		if (error_code == -1)
		{
			std::cout << "Error - failed to send message. Error:" << WSAGetLastError() << "\n";
			getchar();
			exit(1);
		}
		if (error_code != sizeof(c_msg))
		{
			std::cout << "Warning! - Some of the data may not sent successfully.\n";
			getchar();
			exit(1);
		}
	}

	int Client::recvMessage()
	{
		/////////check recvfrom function, what it does. what to put inside it...

		int sizeOfClientAddr = sizeof(struct sockaddr_in);
		int n = recvfrom(m_local_socket, (char*)buffer, BUFFER_SIZE, 0, (struct sockaddr*)&m_remote_address, &sizeOfClientAddr);
		buffer[n] = '\0';
		std::cout << "received: " << buffer << "\n";


	}

	std::string Client::putInstructionInMessage(Instructions ins)
	{
		return createMessage(std::to_string(static_cast<std::underlying_type<Instructions>::type>(ins)));
	}

	

}