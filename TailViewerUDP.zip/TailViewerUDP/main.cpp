#include "TailViewerUDPServer.h"

int main()
{
	udp::TailViewerUDPServer::runTailViewerServer();
}